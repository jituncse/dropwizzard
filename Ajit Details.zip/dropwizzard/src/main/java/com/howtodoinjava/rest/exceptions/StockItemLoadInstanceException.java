package com.howtodoinjava.rest.exceptions;

public class StockItemLoadInstanceException extends StockItemLoadApplicationException {
    public StockItemLoadInstanceException(String message) {
        super(message);
    }

    public StockItemLoadInstanceException(Throwable cause) {
        super(cause);
    }

    public StockItemLoadInstanceException(String message, Throwable cause) {
        super(message, cause);
    }

    public StockItemLoadInstanceException(String message, Throwable cause, Integer returnCode, Integer errorSequence) {
        super(message, cause, returnCode, errorSequence);
    }
}
