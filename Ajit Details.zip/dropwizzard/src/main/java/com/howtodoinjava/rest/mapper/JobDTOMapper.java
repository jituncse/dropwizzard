package com.howtodoinjava.rest.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import com.howtodoinjava.rest.dto.JobDTO;

public class JobDTOMapper implements ResultSetMapper<JobDTO> {

    public JobDTO map(int index, ResultSet rs, StatementContext ctx) throws SQLException
    {
        /*private BigInteger jobId;
        private String status;
        private int processedCount;
        private int successCount;
        private int errorCount;
        private String fileName;
        private Timestamp startTime;
        private Timestamp endTime;*/


        return new JobDTO(rs.getBigDecimal("job_id"),rs.getString("status"),rs.getInt("processed_count"),rs.getInt("success_count"),rs.getInt("error_count"),
        rs.getString("file_name"),rs.getDate("start_time"),rs.getTimestamp("end_time")
                );
    }
}
