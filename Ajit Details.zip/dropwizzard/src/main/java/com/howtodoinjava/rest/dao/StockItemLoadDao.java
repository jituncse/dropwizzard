package com.howtodoinjava.rest.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;

import com.howtodoinjava.rest.dto.JobDTO;
import com.howtodoinjava.rest.mapper.JobDTOMapper;

@UseStringTemplate3StatementLocator
public interface StockItemLoadDao {
	
	  @SqlQuery("SELECT * from jobs where start_time \\= :start_time")
	//  @SqlQuery("SELECT * from jobs where start_time::date = start_time")
	    @Mapper(JobDTOMapper.class)
	    List<JobDTO> getAlljodDetails(@Bind("start_time") Date start_time);
	  
	  @SqlQuery("select * from jobs WHERE job_id=:job_id")
		@Mapper(JobDTOMapper.class)
			List<JobDTO> getJob(@Bind("job_id") BigDecimal job_id);

}
