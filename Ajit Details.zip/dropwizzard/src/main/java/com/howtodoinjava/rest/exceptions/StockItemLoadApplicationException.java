package com.howtodoinjava.rest.exceptions;

public class StockItemLoadApplicationException extends RuntimeException {
 private Integer returnCode;
 private Integer errorSequence;

 public StockItemLoadApplicationException(String message) {
	 super(message);
	  }
 
 public StockItemLoadApplicationException(Throwable cause) {
	 super(cause);
}
 
 public StockItemLoadApplicationException(String message, Throwable cause) {
	 super(message, cause);
}
 
 public StockItemLoadApplicationException(String message, Throwable cause, Integer returnCode, Integer errorSequence) {
	 
	 super(message, cause);
	 this.returnCode = returnCode;
	 this.errorSequence = errorSequence;
 }
 
 public Integer getReturnCode() {
	 return returnCode;
 }
 
 public Integer getErrorSequence() {
	 return errorSequence;
 }
 }
