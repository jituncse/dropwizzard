package com.howtodoinjava.rest.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.howtodoinjava.rest.dao.StockItemLoadDao;
import com.howtodoinjava.rest.dto.JobDTO;
import com.howtodoinjava.rest.exceptions.ErrorSequences;
import com.howtodoinjava.rest.exceptions.StockItemLoadInstanceException;
import com.howtodoinjava.rest.vo.JobStatusResponseVO;
import com.howtodoinjava.rest.vo.Metrics;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.skife.jdbi.v2.DBI;
import org.skife.jdbi.v2.Handle;

public class StockItemLoadService {
	
	private DBI jdbi = new DBI("jdbc:postgresql://localhost:5432/postgres", "postgres","postgres");
	
	private static final SimpleDateFormat stockDateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter recieptedDateFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
	
	
	 public JobStatusResponseVO getJobStatus(String jobID){
	    	if (null == jobID || "".equals(jobID)) {
	    		throw new StockItemLoadInstanceException("The request payload or header fields are invalid/missing", null, 400, ErrorSequences.BAD_REQUEST);
	    	}
	    	List<JobDTO> jobDTOList=null;
	        JobStatusResponseVO jobStatusResponseVO=null;
	        Handle handle = jdbi.open();
	        System.out.println("connection object ----"+ handle);
	        try{
	            StockItemLoadDao stockItemLoadDao = handle.attach(StockItemLoadDao.class);
	            jobDTOList=  stockItemLoadDao.getJob(new BigDecimal(jobID));
	            handle.close();
	        }catch (Exception e){
	            handle.close();
	        }
	        finally {
	            handle.close();
	        }

	        if (jobDTOList == null || jobDTOList.isEmpty()) {
	            throw new StockItemLoadInstanceException("Job not found", null, 404, ErrorSequences.NO_RECORDS_FOUND);
	        }else{
	            JobDTO jobDTO=jobDTOList.get(0);
	            jobStatusResponseVO=new JobStatusResponseVO();
	            jobStatusResponseVO.setStatus(jobDTO.getStatus());
	            jobStatusResponseVO.setFile(jobDTO.getFileName());

	            Metrics metrics=new Metrics();
	            metrics.setJobStarted(stockDateFormatter.format(jobDTO.getStartTime()));
	            try {
	                metrics.setJobFinished(stockDateFormatter.format(jobDTO.getEndTime()));
	            }catch (Exception e){

	            }
	            metrics.setProcessedCount(""+jobDTO.getProcessedCount());
	            metrics.setSuccessCount(""+jobDTO.getSuccessCount());
	            metrics.setErrorCount(""+jobDTO.getErrorCount());
	            jobStatusResponseVO.setMetrics(metrics);
	        }
	        return jobStatusResponseVO;
	    }
	 
	 
	 public List<JobStatusResponseVO> getAllJobStatus(String dateString){
		 System.out.println("start of getAllJobStatus method");
	    	List<JobStatusResponseVO> list = new ArrayList<>();
	    	if(dateString == null || dateString.trim().length()==0) {
	    	}
	    	
	    	List<JobDTO> jobDTOList=null;
	        JobStatusResponseVO jobStatusResponseVO=null;
	        Handle handle = jdbi.open();
	        System.out.println("connection object ----"+ handle);
	        try{
	            StockItemLoadDao stockItemLoadDao = handle.attach(StockItemLoadDao.class);
	            
	            jobDTOList=  stockItemLoadDao.getAlljodDetails(getCurrentDate());
	            System.out.println("response from database----"+ jobDTOList);
	            handle.close();
	        }catch (Exception e){
	            handle.close();
	        }
	        finally {
	            handle.close();
	        }
	  
	        if (jobDTOList == null || jobDTOList.isEmpty()) {
	            throw new StockItemLoadInstanceException("Job not found", null, 404, ErrorSequences.NO_RECORDS_FOUND);
	        }else{
	        	for (JobDTO jobDTO1 : jobDTOList) {
	            JobDTO jobDTO=jobDTO1;
	            jobStatusResponseVO=new JobStatusResponseVO();
	            jobStatusResponseVO.setStatus(jobDTO.getStatus());
	            jobStatusResponseVO.setFile(jobDTO.getFileName());

	            Metrics metrics=new Metrics();
	            metrics.setJobStarted(stockDateFormatter.format(jobDTO.getStartTime()));
	            try {
	                metrics.setJobFinished(stockDateFormatter.format(jobDTO.getEndTime()));
	            }catch (Exception e){

	            }
	            metrics.setProcessedCount(""+jobDTO.getProcessedCount());
	            metrics.setSuccessCount(""+jobDTO.getSuccessCount());
	            metrics.setErrorCount(""+jobDTO.getErrorCount());
	            jobStatusResponseVO.setMetrics(metrics);

	            list.add(jobStatusResponseVO);
	        }
	        	System.out.println("end of getAllJobStatus method");
	        return list;
	    } 
	 }
	 
	 private  Date getCurrentDate() {
					LocalDateTime localDateTime = LocalDateTime.now();
					Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
					return date;
		} 
	 

}
