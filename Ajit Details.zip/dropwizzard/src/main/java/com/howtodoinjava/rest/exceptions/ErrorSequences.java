package com.howtodoinjava.rest.exceptions;

public class ErrorSequences {
    public static final Integer AN_UNEXPECTED_ERROR_HAS_OCCURRED = 0;
    public static final Integer COULD_NOT_CREATE_STATEMENT = 1;
    public static final Integer PAYLOAD_IS_INCOMPLETE = 2;
    public static final Integer CONNECTION_TO_UNICA_FAILED = 3;
    public static final Integer CONNECTION_FAILED = 4;
    public static final Integer CONNECTION_TO_SALESFORCE_FAILED = 5;
    public static final Integer AWS_SERVICE_FAILURE = 6;
    public static final Integer JSON_PARSING_ERROR = 7;
    public static final Integer JSON_OBJECT_WAS_NOT_WELL_FORMED = 8;
    public static final Integer REQUEST_REQUIRES_CORRECT_AUTH_STRING_BUT_GOT_INCORRECT_AUTH_STRING = 10;
    public static final Integer NO_RECORDS_FOUND = 11;
    public static final Integer UNSUPPORTED_MEDIA_TYPE = 12;
    public static final Integer MAPPER_CLASS_NOT_FOUND = 13;
    public static final Integer DEFAULT_RATE_LIMIT_EXCEEDED = 14;
    public static final Integer BAD_REQUEST = 15;
}
