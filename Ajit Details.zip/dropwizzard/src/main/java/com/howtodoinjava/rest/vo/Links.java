package com.howtodoinjava.rest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Links {

public String processLog;
public String errorLog;
public String errorData;
public String getProcessLog() {
	return processLog;
}
public void setProcessLog(String processLog) {
	this.processLog = processLog;
}
public String getErrorLog() {
	return errorLog;
}
public void setErrorLog(String errorLog) {
	this.errorLog = errorLog;
}
public String getErrorData() {
	return errorData;
}
public void setErrorData(String errorData) {
	this.errorData = errorData;
}
@Override
public String toString() {
	return "Links [processLog=" + processLog + ", errorLog=" + errorLog + ", errorData=" + errorData + "]";
}
public Links(String processLog, String errorLog, String errorData) {
	super();
	this.processLog = processLog;
	this.errorLog = errorLog;
	this.errorData = errorData;
}
public Links() {
	super();
	// TODO Auto-generated constructor stub
}



}
