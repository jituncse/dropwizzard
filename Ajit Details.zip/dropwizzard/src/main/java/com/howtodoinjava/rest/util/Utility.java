package com.howtodoinjava.rest.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.howtodoinjava.rest.dto.JobDTO;

public class Utility {
	
	
public static List<JobDTO> getAllJobs(){
	List<JobDTO> dtos = null;
dtos = new ArrayList<>();

dtos.add(new JobDTO(BigDecimal.valueOf(37287706),"completed", 9600500, 9600500 ,0 ,"nb_blueyonder_fresh_item_soh_20210816.dat", new Date(), new Date()));
dtos.add(new JobDTO(BigDecimal.valueOf(37287705),"completed", 311144, 311144 ,0 ,"ExceptionItemStock_20210817_051007.dat", new Date(), new Date()));
dtos.add(new JobDTO(BigDecimal.valueOf(37287704),"completed", 3095231, 25000,0 ,"nb_blueyonder_orders_20210816.dat.gz", new Date(), new Date()));
dtos.add(new JobDTO(BigDecimal.valueOf(37287703),"completed", 279419, 115806,0 ,"BlueYonder_Orders_20210817_033300.TXT.gz", new Date(), new Date()));
dtos.add(new JobDTO(BigDecimal.valueOf(37287702),"completed", 975438, 268883,0 ,"BlueYonder_Orders_20210817_030303.TXT.gz", new Date(), new Date()));
dtos.add(new JobDTO(BigDecimal.valueOf(37245056),"completed", 310157, 310157,0 ,"BlueYonder_Produce_Stocks_20210817_033300.TXT.gz", new Date(), new Date()));
dtos.add(new JobDTO(BigDecimal.valueOf(37213073),"completed", 8244984, 8244984,0 ,"nb_blueyonder_item_soh_20210816.dat03.gz", new Date(), new Date()));
dtos.add(new JobDTO(BigDecimal.valueOf(37213072),"completed", 20000000, 20000000 ,0 ,"nb_blueyonder_item_soh_20210816.dat02.gz", new Date(), new Date()));
dtos.add(new JobDTO(BigDecimal.valueOf(37213071),"completed", 20000000, 20000000 ,0 ,"nb_blueyonder_item_soh_20210816.dat01.gz", new Date(), new Date()));
dtos.add(new JobDTO(BigDecimal.valueOf(37213070),"completed", 20000000, 20000000 ,0 ,"nb_blueyonder_item_soh_20210816.dat00", new Date(), new Date()));
	
	
	return dtos;
	
	
	
}

public static List<JobDTO> getJob(BigDecimal bigDecimal){
	
	List<JobDTO> list = new ArrayList<>();
	
	
	for (JobDTO jobDTO : getAllJobs()) {
        if (jobDTO.getJobId().equals(bigDecimal)) {
        	list.add(jobDTO);
        }
    }
    return list;
}

/*public static void main(String[] args) {
	
List<JobDTO> list = new ArrayList<>();
BigDecimal bigDecimal =BigDecimal.valueOf(37287706);
	
	for (JobDTO jobDTO : getAllJobs()) {
        if (jobDTO.getJobId().equals(bigDecimal)) {
        	//System.out.println(jobDTO);
        	list.add(jobDTO);
        }
    }
    System.out.println(list);
	
}
	*/
	
}


