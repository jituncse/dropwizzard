package com.howtodoinjava.rest.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class JobDTO {

    private BigDecimal jobId;
    private String status;
    private int processedCount;
    private int successCount;
    private int errorCount;
    private String fileName;
    private Date startTime;
    private Date endTime;
	public JobDTO(BigDecimal jobId, String status, int processedCount, int successCount, int errorCount,
			String fileName, Date startTime, Date endTime) {
		super();
		this.jobId = jobId;
		this.status = status;
		this.processedCount = processedCount;
		this.successCount = successCount;
		this.errorCount = errorCount;
		this.fileName = fileName;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	public JobDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BigDecimal getJobId() {
		return jobId;
	}
	public void setJobId(BigDecimal jobId) {
		this.jobId = jobId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getProcessedCount() {
		return processedCount;
	}
	public void setProcessedCount(int processedCount) {
		this.processedCount = processedCount;
	}
	public int getSuccessCount() {
		return successCount;
	}
	public void setSuccessCount(int successCount) {
		this.successCount = successCount;
	}
	public int getErrorCount() {
		return errorCount;
	}
	public void setErrorCount(int errorCount) {
		this.errorCount = errorCount;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	@Override
	public String toString() {
		return "JobDTO [jobId=" + jobId + ", status=" + status + ", processedCount=" + processedCount
				+ ", successCount=" + successCount + ", errorCount=" + errorCount + ", fileName=" + fileName
				+ ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}



}
