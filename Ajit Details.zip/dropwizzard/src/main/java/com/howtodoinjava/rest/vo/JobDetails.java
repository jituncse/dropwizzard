package com.howtodoinjava.rest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class JobDetails {
	
	public String status;
	public String statusMessage; //nf
	public String file;
	public String jobStarted;
	public String jobFinished;
	public String processedCount;
	public String successCount;
	public String errorCount;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getJobStarted() {
		return jobStarted;
	}
	public void setJobStarted(String jobStarted) {
		this.jobStarted = jobStarted;
	}
	public String getJobFinished() {
		return jobFinished;
	}
	public void setJobFinished(String jobFinished) {
		this.jobFinished = jobFinished;
	}
	public String getProcessedCount() {
		return processedCount;
	}
	public void setProcessedCount(String processedCount) {
		this.processedCount = processedCount;
	}
	public String getSuccessCount() {
		return successCount;
	}
	public void setSuccessCount(String successCount) {
		this.successCount = successCount;
	}
	public String getErrorCount() {
		return errorCount;
	}
	public void setErrorCount(String errorCount) {
		this.errorCount = errorCount;
	}
	public JobDetails(String status, String statusMessage, String file, String jobStarted, String jobFinished,
			String processedCount, String successCount, String errorCount) {
		super();
		this.status = status;
		this.statusMessage = statusMessage;
		this.file = file;
		this.jobStarted = jobStarted;
		this.jobFinished = jobFinished;
		this.processedCount = processedCount;
		this.successCount = successCount;
		this.errorCount = errorCount;
	}
	public JobDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
