package com.howtodoinjava.rest.controller;

import javax.validation.Validator;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.codahale.metrics.annotation.Timed;
import com.howtodoinjava.rest.exceptions.StockItemLoadApplicationException;
import com.howtodoinjava.rest.service.StockItemLoadService;
import com.howtodoinjava.rest.vo.JobStatusResponseVO;

import io.swagger.annotations.*;

@Path("/stockwriter/v2")
@Produces(MediaType.APPLICATION_JSON)
public class EmployeeRESTController {
 
    private final Validator validator;
 
    public EmployeeRESTController(Validator validator) {
        this.validator = validator;
    }
 
    @Timed
    @GET
    @Produces(value = MediaType.APPLICATION_JSON)
    @Path("jobs/{jobId}/status")
    @ApiOperation(value = "Gets status of stockitemload job.", response = JobStatusResponseVO.class)
    @ApiResponses(value = {@ApiResponse(code = 404, message = "Stock Item not found")})
    public Response getJobStatus(@ApiParam(value = "Job ID", required = true) @PathParam("jobId") String   jobId, @Context HttpHeaders headers, 
    		@Context UriInfo ui, 
    		@QueryParam("date") @DefaultValue("Default") String dateString) {
       // Employee employee = EmployeeDB.getJobStatus(jobId);
     //   if (employee != null)
      System.out.println(ui);
      System.out.println("getAbsolutePath---" + ui.getAbsolutePath());
      
      MultivaluedMap<String, String> queryParams = ui.getQueryParameters();
      MultivaluedMap<String, String> pathParams = ui.getPathParameters();
      
      System.out.println("queryParams---" + queryParams);
      System.out.println("pathParams---" +pathParams);
   
      System.out.println(dateString);
      
      StockItemLoadService stockItemLoadService = new StockItemLoadService();
      try {
    	  
      
      if("@all".equalsIgnoreCase(jobId)) {
    	  System.out.println("if block executed");
    	  return Response.ok(stockItemLoadService.getAllJobStatus(dateString)).build();
      }
      else {
    	  System.out.println("else block executed");
    	  return Response.ok(stockItemLoadService.getJobStatus(jobId)).build();
      }
      }
      catch (StockItemLoadApplicationException e) {
    	  System.out.println("hello1");
    	  System.out.println("error code----" + e.getReturnCode());
    	  System.out.println("error message----" + e.getMessage());
    	  System.out.println("error sequence----" + e.getErrorSequence());
          throw new StockItemLoadApplicationException(e.getMessage(), e.getCause(), e.getReturnCode(), e.getErrorSequence());
      } catch (Throwable e) {
    	  System.out.println("hello2");
    	  System.out.println(e);
          throw new StockItemLoadApplicationException(e.getMessage(), e.getCause(), 500, null);
      }
      
           
       // else
        //    return Response.status(Status.NOT_FOUND).build();
    }
 
    /*@GET
    @Path("jobs/@all/status")
   // @ApiResponses(value = {@ApiResponse(code = 404, message = "Stock Item not found")})
    public Response getJobStatus(@Context HttpHeaders headers, @Context UriInfo ui, @QueryParam("date") @DefaultValue("new Date()") String dateString) {
       // Employee employee = EmployeeDB.getJobStatus(jobId);
     //   if (employee != null)
      System.out.println(ui);
      System.out.println("getAbsolutePath---" + ui.getAbsolutePath());
      
      MultivaluedMap<String, String> queryParams = ui.getQueryParameters();
      MultivaluedMap<String, String> pathParams = ui.getPathParameters();
      
      System.out.println("queryParams---" + queryParams);
      System.out.println("pathParams---" +pathParams);
   
      System.out.println(dateString);
            return Response.ok(EmployeeDB.getAllJobStatus()).build();
       // else
        //    return Response.status(Status.NOT_FOUND).build();
    }
    
    
    /*@POST
    public Response createEmployee(Employee employee) throws URISyntaxException {
        // validation
        Set<ConstraintViolation<Employee>> violations = validator.validate(employee);
        Employee e = EmployeeDB.getEmployee(employee.getId());
        if (violations.size() > 0) {
            ArrayList<String> validationMessages = new ArrayList<String>();
            for (ConstraintViolation<Employee> violation : violations) {
                validationMessages.add(violation.getPropertyPath().toString() + ": " + violation.getMessage());
            }
            return Response.status(Status.BAD_REQUEST).entity(validationMessages).build();
        }
        if (e != null) {
            EmployeeDB.updateEmployee(employee.getId(), employee);
            return Response.created(new URI("/employees/" + employee.getId()))
                    .build();
        } else
            return Response.status(Status.NOT_FOUND).build();
    } */
 
  /*  @PUT
    @Path("/{id}")
    public Response updateEmployeeById(@PathParam("id") Integer id, Employee employee) {
        // validation
        Set<ConstraintViolation<Employee>> violations = validator.validate(employee);
        Employee e = EmployeeDB.getEmployee(employee.getId());
        if (violations.size() > 0) {
            ArrayList<String> validationMessages = new ArrayList<String>();
            for (ConstraintViolation<Employee> violation : violations) {
                validationMessages.add(violation.getPropertyPath().toString() + ": " + violation.getMessage());
            }
            return Response.status(Status.BAD_REQUEST).entity(validationMessages).build();
        }
        if (e != null) {
            employee.setId(id);
            EmployeeDB.updateEmployee(id, employee);
            return Response.ok(employee).build();
        } else
            return Response.status(Status.NOT_FOUND).build();
    } */
 
  /*  @DELETE
    @Path("/{id}")
    public Response removeEmployeeById(@PathParam("id") Integer id) {
        Employee employee = EmployeeDB.getEmployee(id);
        if (employee != null) {
            EmployeeDB.removeEmployee(id);
            return Response.ok().build();
        } else
            return Response.status(Status.NOT_FOUND).build();
    } */
}
