/*package com.howtodoinjava.rest.dao;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import com.howtodoinjava.rest.dto.JobDTO;
import com.howtodoinjava.rest.exceptions.ErrorSequences;
import com.howtodoinjava.rest.exceptions.StockItemLoadInstanceException;
import com.howtodoinjava.rest.representations.Employee;
import com.howtodoinjava.rest.util.Utility;
import com.howtodoinjava.rest.vo.JobDetails;
import com.howtodoinjava.rest.vo.JobStatusResponseVO;
import com.howtodoinjava.rest.vo.Links;
import com.howtodoinjava.rest.vo.Metrics;

public class EmployeeDB {
	
	private static final SimpleDateFormat stockDateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final DateTimeFormatter recieptedDateFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
    
    public static HashMap<Integer, Employee> employees = new HashMap<>();
    static{
        employees.put(1, new Employee(1, "Lokesh", "Gupta", "India"));
        employees.put(2, new Employee(2, "John", "Gruber", "USA"));
        employees.put(3, new Employee(3, "Melcum", "Marshal", "AUS"));
    }
     
    public static List<Employee> getEmployees(){
        return new ArrayList<Employee>(employees.values());
    }
     
    public static Employee getEmployee(Integer id){
        return employees.get(id);
    }
     
    public static void updateEmployee(Integer id, Employee employee){
        employees.put(id, employee);
    }
     
    public static void removeEmployee(Integer id){
        employees.remove(id);
    }
    
    public static JobStatusResponseVO getJobStatus(String jobID){
    	if (null == jobID || "".equals(jobID)) {
    		throw new StockItemLoadInstanceException("The request payload or header fields are invalid/missing", null, 400, ErrorSequences.BAD_REQUEST);
    	}
    	
    	List<JobDTO> jobDTOList=null;
        JobStatusResponseVO jobStatusResponseVO=null;
           jobDTOList=  Utility.getJob(new BigDecimal(jobID));
     //   jobDTOList =  Utility.getAllJobs();
           // handle.close();
       

        if (jobDTOList == null || jobDTOList.isEmpty()) {
        	System.out.println("response from db is :" + jobDTOList);
            throw new StockItemLoadInstanceException("Job not found", null, 404, ErrorSequences.NO_RECORDS_FOUND);
        }else{
            JobDTO jobDTO=jobDTOList.get(0);
            jobStatusResponseVO=new JobStatusResponseVO();
            jobStatusResponseVO.setStatus(jobDTO.getStatus());
            jobStatusResponseVO.setFile(jobDTO.getFileName());

            Metrics metrics=new Metrics();
            metrics.setJobStarted(stockDateFormatter.format(jobDTO.getStartTime()));
            try {
                metrics.setJobFinished(stockDateFormatter.format(jobDTO.getEndTime()));
            }catch (Exception e){

            }
            metrics.setProcessedCount(""+jobDTO.getProcessedCount());
            metrics.setSuccessCount(""+jobDTO.getSuccessCount());
            metrics.setErrorCount(""+jobDTO.getErrorCount());
            jobStatusResponseVO.setMetrics(metrics);

            Links links=new Links();
            links.setProcessLog("/Success_"+"abc.txt");
            links.setErrorLog("/Error_"+"def.txt");
            jobStatusResponseVO.setLinks(links);
        }
        return jobStatusResponseVO;
    }
    
 /*   public static List<JobStatusResponseVO> getAllJobStatus(){
    	List<JobStatusResponseVO> list = new ArrayList<>();
    	if (null == jobID || "".equals(jobID)) {
    		throw new StockItemLoadInstanceException("The request payload or header fields are invalid/missing", null, 400, ErrorSequences.BAD_REQUEST);
    	} 
    	
    	List<JobDTO> jobDTOList=null;
        JobStatusResponseVO jobStatusResponseVO=null;
          //  jobDTOList=  Utility.getJob(new BigDecimal(jobID));
        jobDTOList =  Utility.getAllJobs();
           // handle.close();
       

        if (jobDTOList == null || jobDTOList.isEmpty()) {
            throw new StockItemLoadInstanceException("Job not found", null, 404, ErrorSequences.NO_RECORDS_FOUND);
        }else{
        	for (JobDTO jobDTO1 : jobDTOList) {
                	//list.add(jobDTO);
            
        	
            JobDTO jobDTO=jobDTO1;
            jobStatusResponseVO=new JobStatusResponseVO();
            jobStatusResponseVO.setStatus(jobDTO.getStatus());
            jobStatusResponseVO.setFile(jobDTO.getFileName());

            Metrics metrics=new Metrics();
            metrics.setJobStarted(stockDateFormatter.format(jobDTO.getStartTime()));
            try {
                metrics.setJobFinished(stockDateFormatter.format(jobDTO.getEndTime()));
            }catch (Exception e){

            }
            metrics.setProcessedCount(""+jobDTO.getProcessedCount());
            metrics.setSuccessCount(""+jobDTO.getSuccessCount());
            metrics.setErrorCount(""+jobDTO.getErrorCount());
            jobStatusResponseVO.setMetrics(metrics);

            Links links=new Links();
            links.setProcessLog("/Success_"+"abc.txt");
            links.setErrorLog("/Error_"+"def.txt");
            jobStatusResponseVO.setLinks(links); 
            list.add(jobStatusResponseVO);
        }
        return list;
    } 
    
    public static List<JobDetails> getAllJobStatus(String dateString){
    	List<JobDetails> list = new ArrayList<>();
    	JobDetails jobDetails = null;
    	if(dateString == null || dateString.trim().length()==0) {
    		
    	}
    	List<JobDTO> jobDTOList =  Utility.getAllJobs();
        if (jobDTOList == null || jobDTOList.isEmpty()) {
            throw new StockItemLoadInstanceException("Job not found", null, 404, ErrorSequences.NO_RECORDS_FOUND);
        }else{
        	for (JobDTO jobDTO1 : jobDTOList) {
        		jobDetails=new JobDetails();
        		jobDetails.setStatus(jobDTO1.getStatus());
        		jobDetails.setFile(jobDTO1.getFileName());
        		jobDetails.setJobStarted(stockDateFormatter.format(jobDTO1.getStartTime()));
        		jobDetails.setJobFinished(stockDateFormatter.format(jobDTO1.getEndTime()));
        		jobDetails.setProcessedCount(""+jobDTO1.getProcessedCount());
        		jobDetails.setSuccessCount(""+jobDTO1.getSuccessCount());
        		jobDetails.setErrorCount(""+jobDTO1.getErrorCount());
            list.add(jobDetails);
        }
        return list;
    } 
}
} */