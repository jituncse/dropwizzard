package com.howtodoinjava.rest.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class JobStatusResponseVO {

public String status;
public String statusMessage; //nf
public String file;
public Metrics metrics;
    public Links links;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public Metrics getMetrics() {
		return metrics;
	}
	public void setMetrics(Metrics metrics) {
		this.metrics = metrics;
	}
	public Links getLinks() {
		return links;
	}
	public void setLinks(Links links) {
		this.links = links;
	}
	@Override
	public String toString() {
		return "JobStatusResponseVO [status=" + status + ", statusMessage=" + statusMessage + ", file=" + file
				+ ", metrics=" + metrics + ", links=" + links + "]";
	}
	public JobStatusResponseVO(String status, String statusMessage, String file, Metrics metrics, Links links) {
		super();
		this.status = status;
		this.statusMessage = statusMessage;
		this.file = file;
		this.metrics = metrics;
		this.links = links;
	}
	public JobStatusResponseVO() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
